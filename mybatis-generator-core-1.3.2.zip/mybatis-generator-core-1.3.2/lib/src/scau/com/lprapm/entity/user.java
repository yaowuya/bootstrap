package scau.com.lprapm.entity;

import java.util.Date;

public class user {
    private String userid;

    private String username;

    private String usertruename;

    private String userpasswrod;

    private String useremail;

    private String userphone;

    private Date userbirthday;

    private String usersex;

    private String usercompany;

    private String userdept;

    private String userdeptphone;

    private String userdeptdesc;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getUsertruename() {
        return usertruename;
    }

    public void setUsertruename(String usertruename) {
        this.usertruename = usertruename == null ? null : usertruename.trim();
    }

    public String getUserpasswrod() {
        return userpasswrod;
    }

    public void setUserpasswrod(String userpasswrod) {
        this.userpasswrod = userpasswrod == null ? null : userpasswrod.trim();
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail == null ? null : useremail.trim();
    }

    public String getUserphone() {
        return userphone;
    }

    public void setUserphone(String userphone) {
        this.userphone = userphone == null ? null : userphone.trim();
    }

    public Date getUserbirthday() {
        return userbirthday;
    }

    public void setUserbirthday(Date userbirthday) {
        this.userbirthday = userbirthday;
    }

    public String getUsersex() {
        return usersex;
    }

    public void setUsersex(String usersex) {
        this.usersex = usersex == null ? null : usersex.trim();
    }

    public String getUsercompany() {
        return usercompany;
    }

    public void setUsercompany(String usercompany) {
        this.usercompany = usercompany == null ? null : usercompany.trim();
    }

    public String getUserdept() {
        return userdept;
    }

    public void setUserdept(String userdept) {
        this.userdept = userdept == null ? null : userdept.trim();
    }

    public String getUserdeptphone() {
        return userdeptphone;
    }

    public void setUserdeptphone(String userdeptphone) {
        this.userdeptphone = userdeptphone == null ? null : userdeptphone.trim();
    }

    public String getUserdeptdesc() {
        return userdeptdesc;
    }

    public void setUserdeptdesc(String userdeptdesc) {
        this.userdeptdesc = userdeptdesc == null ? null : userdeptdesc.trim();
    }
}