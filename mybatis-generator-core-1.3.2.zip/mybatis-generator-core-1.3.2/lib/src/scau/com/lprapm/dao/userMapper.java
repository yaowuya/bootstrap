package scau.com.lprapm.dao;

import scau.com.lprapm.entity.user;

public interface userMapper {
    int deleteByPrimaryKey(String userid);

    int insert(user record);

    int insertSelective(user record);

    user selectByPrimaryKey(String userid);

    int updateByPrimaryKeySelective(user record);

    int updateByPrimaryKey(user record);
}